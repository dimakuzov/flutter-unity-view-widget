﻿using System;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

namespace PhotoFilters
{
    [Serializable]
    [PostProcess(typeof(PoprocketRenderer), PostProcessEvent.BeforeStack, "PhotoFilters/Poprocket")]
    public sealed class Poprocket : PostProcessEffectSettings
    {
        [Range(0f, 1f), Tooltip("Photo Filter Intensivity")]
        public FloatParameter intensivity = new FloatParameter { value = 1.0f };
        public ColorParameter colorInner = new ColorParameter { value = new Color(0.8f, 0.149f, 0.275f, 1.0f) };
        public ColorParameter colorOuter = new ColorParameter { value = new Color(0.06f, 0.02f, 0.18f, 1.0f) };


        public override bool IsEnabledAndSupported(PostProcessRenderContext context)
        {
            return enabled.value;
        }
    }

    public sealed class PoprocketRenderer : PostProcessEffectRenderer<Poprocket>
    {
        public override void Render(PostProcessRenderContext context)
        {
            var sheet = context.propertySheets.Get(Shader.Find("Photo Filters/LWRP/Poprocket"));
            sheet.properties.SetFloat("_Intensivity", settings.intensivity);
            sheet.properties.SetColor("_ColorInner", settings.colorInner);
            sheet.properties.SetColor("_ColorOuter", settings.colorOuter);
            context.command.BlitFullscreenTriangle(context.source, context.destination, sheet, 0);
        }
    }
}


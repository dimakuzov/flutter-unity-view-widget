﻿using System;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

namespace PhotoFilters
{
    [Serializable]
    [PostProcess(typeof(WaldenRenderer), PostProcessEvent.BeforeStack, "PhotoFilters/Walden")]
    public sealed class Walden : PostProcessEffectSettings
    {
        [Range(0f, 1f), Tooltip("Photo Filter Intensivity")]
        public FloatParameter intensivity = new FloatParameter { value = 1.0f };

        [Tooltip("Ramp (3D color mask)")]
        public TextureParameter ramp = new TextureParameter();

        [Range(0f, 1f), Tooltip("Vignette Radius")]
        public FloatParameter vignetteRadius = new FloatParameter { value = 0.977f };

        [Range(0f, 1f), Tooltip("Vignette Softness")]
        public FloatParameter vignetteSoftness = new FloatParameter { value = 0.5f };


        public override bool IsEnabledAndSupported(PostProcessRenderContext context)
        {
            return enabled.value
                && ramp.value != null;
        }
    }

    public sealed class WaldenRenderer : PostProcessEffectRenderer<Walden>
    {
        public override void Render(PostProcessRenderContext context)
        {
            var sheet = context.propertySheets.Get(Shader.Find("Photo Filters/LWRP/Walden"));
            sheet.properties.SetFloat("_Intensivity", settings.intensivity);
            sheet.properties.SetFloat("_VignetteRadius", settings.vignetteRadius);
            sheet.properties.SetFloat("_VignetteSoftness", settings.vignetteSoftness);
            sheet.properties.SetTexture("_Ramp", settings.ramp);
            context.command.BlitFullscreenTriangle(context.source, context.destination, sheet, 0);
        }
    }
}


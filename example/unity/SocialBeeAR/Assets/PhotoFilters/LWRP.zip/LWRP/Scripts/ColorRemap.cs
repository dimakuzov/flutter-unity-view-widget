﻿using System;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

namespace PhotoFilters
{
    [Serializable]
    [PostProcess(typeof(ColorRemapRenderer), PostProcessEvent.BeforeStack, "PhotoFilters/Color Remap")]
    public sealed class ColorRemap : PostProcessEffectSettings
    {
        [Range(0f, 1f), Tooltip("Photo Filter Intensivity")]
        public FloatParameter intensivity = new FloatParameter { value = 1.0f };

        [Tooltip("Ramp (3D color mask)")]
        public TextureParameter ramp = new TextureParameter();

        public override bool IsEnabledAndSupported(PostProcessRenderContext context)
        {
            return enabled.value
                && ramp.value != null;
        }
    }

    public sealed class ColorRemapRenderer : PostProcessEffectRenderer<ColorRemap>
    {
        public override void Render(PostProcessRenderContext context)
        {
            var sheet = context.propertySheets.Get(Shader.Find("Photo Filters/LWRP/Color Remap"));
            sheet.properties.SetFloat("_Intensivity", settings.intensivity);
            sheet.properties.SetTexture("_Ramp", settings.ramp);
            context.command.BlitFullscreenTriangle(context.source, context.destination, sheet, 0);
        }
    }
}


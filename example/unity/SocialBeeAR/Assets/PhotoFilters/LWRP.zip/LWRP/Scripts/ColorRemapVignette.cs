﻿using System;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

namespace PhotoFilters
{
    [Serializable]
    [PostProcess(typeof(ColorRemapVignetteRenderer), PostProcessEvent.BeforeStack, "PhotoFilters/Color Remap with Vignette")]
    public sealed class ColorRemapVignette : PostProcessEffectSettings
    {
        [Range(0f, 1f), Tooltip("Photo Filter Intensivity")]
        public FloatParameter intensivity = new FloatParameter { value = 1.0f };

        [Tooltip("Ramp (3D color mask)")]
        public TextureParameter ramp = new TextureParameter();

        [Range(0f, 1f), Tooltip("Vignette Radius")]
        public FloatParameter vignetteRadius = new FloatParameter { value = 0.977f };

        [Range(0f, 1f), Tooltip("Vignette Softness")]
        public FloatParameter vignetteSoftness = new FloatParameter { value = 0.5f };

        [Range(0f, 1f), Tooltip("Vignette Opacity")]
        public FloatParameter vignetteOpacity = new FloatParameter { value = 1.0f };

        public override bool IsEnabledAndSupported(PostProcessRenderContext context)
        {
            return enabled.value
                && ramp.value != null;
        }
    }

    public sealed class ColorRemapVignetteRenderer : PostProcessEffectRenderer<ColorRemapVignette>
    {
        public override void Render(PostProcessRenderContext context)
        {
            var sheet = context.propertySheets.Get(Shader.Find("Photo Filters/LWRP/Color Remap with vignette"));
            sheet.properties.SetFloat("_Intensivity", settings.intensivity);
            sheet.properties.SetTexture("_Ramp", settings.ramp);
            sheet.properties.SetFloat("_VignetteRadius", settings.vignetteRadius);
            sheet.properties.SetFloat("_VignetteSoftness", settings.vignetteSoftness);
            sheet.properties.SetFloat("_VignetteAlpha", settings.vignetteOpacity);
            context.command.BlitFullscreenTriangle(context.source, context.destination, sheet, 0);
        }
    }
}


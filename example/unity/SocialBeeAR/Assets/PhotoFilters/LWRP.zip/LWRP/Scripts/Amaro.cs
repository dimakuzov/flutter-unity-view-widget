﻿using System;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

namespace PhotoFilters
{   
    [Serializable]
    [PostProcess(typeof(AmaroRenderer), PostProcessEvent.BeforeStack, "PhotoFilters/Amaro")]
    public sealed class Amaro : PostProcessEffectSettings
    {
        [Range(0f, 1f), Tooltip("Photo Filter Intensivity")]
        public FloatParameter intensivity = new FloatParameter { value = 1.0f };

        [Tooltip("Ramp (3D color mask)")]
        public TextureParameter ramp = new TextureParameter();

        [Range(0f, 1f), Tooltip("Vignette Radius")]
        public FloatParameter vignetteRadius = new FloatParameter { value = 0.977f };

        [Range(0f, 1f), Tooltip("Vignette Softness")]
        public FloatParameter vignetteSoftness = new FloatParameter { value = 0.5f };


        public override bool IsEnabledAndSupported(PostProcessRenderContext context)
        {
            return enabled.value
                && ramp.value != null;
        }
    }

    public sealed class AmaroRenderer : PostProcessEffectRenderer<Amaro>
    {
        public override void Render(PostProcessRenderContext context)
        {
            var sheet = context.propertySheets.Get(Shader.Find("Photo Filters/LWRP/Amaro"));
            sheet.properties.SetFloat("_Intensivity", settings.intensivity);
            sheet.properties.SetFloat("_VignetteRadius", settings.vignetteRadius);
            sheet.properties.SetFloat("_VignetteSoftness", settings.vignetteSoftness);
            sheet.properties.SetTexture("_Ramp", settings.ramp);
            context.command.BlitFullscreenTriangle(context.source, context.destination, sheet, 0);
        }
    }
}

